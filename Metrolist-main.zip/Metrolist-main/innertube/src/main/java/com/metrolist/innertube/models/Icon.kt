package com.metrolist.innertube.models

import kotlinx.serialization.Serializable

@Serializable
data class Icon(
    val iconType: String,
)
