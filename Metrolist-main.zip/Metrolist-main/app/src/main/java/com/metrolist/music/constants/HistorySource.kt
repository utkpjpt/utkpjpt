package com.metrolist.music.constants

enum class HistorySource {
    LOCAL, REMOTE
}
