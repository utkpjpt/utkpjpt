package com.metrolist.music.utils

fun reportException(throwable: Throwable) {
    throwable.printStackTrace()
}
